package org.me.gcu.labstuff.mappingstuff;

public class Earthquake {

    private String title;
    private String description;
    private String link;
    private String pubDate;
    private String category;
    private Double latitude;
    private Double longitude;
    private Double magnitude;
    private int depth;

    public Earthquake()
    {
        this.title = "";
        this.description = "";
        this.link ="";
        this.pubDate ="";
        this.category = "";
        this.latitude = 0.00;
        this.longitude = 0.00;
        this.magnitude = 0.00;
        this.depth = 0;
    }

    public Earthquake(String title, String description, String link, String pubDate, String category, Double latitude, Double longitude, Double magnitude, int depth)
    {
        this.title = title;
        this.description = description;
        this.link = link;
        this.pubDate = pubDate;
        this.category = category;
        this.latitude = latitude;
        this.longitude = longitude;
        this.magnitude = magnitude;
        this.depth = depth;
    }

    public String getTitle()
    {
        return title;
    }

    public void setTitle(String title)
    {
        this.title = title;
    }

    public String getDescription()
    {
        return description;
    }

    public void setDescription(String description)
    {
        this.description = description;
    }

    public Double getLatitude()
    {
        return latitude;
    }
///////////////////////////

    public void setLink(String link)
    {
        this.link = link;
    }

    public String getLink()
    {
        return link;
    }
///////////////////////////    /////////

    public void setPubDate(String pubDate)
    {
        this.pubDate = pubDate;
    }

    public String getPubDate()
    {
        return pubDate;
    }
///////////////////////////////////////

    public void setCategory(String category)
    {
        this.category = category;
    }

    public String getCategory()
    {
        return category;
    }
    public void setLatitude(Double latitude)
    {
        this.latitude = latitude;
    }

    public Double getLongitude()
    {
        return longitude;
    }

    public void setLongitude(Double longitude)
    {
        this.longitude = longitude;
    }

    public Double getMagnitude()
    {
        return magnitude;
    }

    public void setMagnitude(Double magnitude)
    {
        this.magnitude = magnitude;
    }

    public int getDepth()
    {
        return depth;
    }

    public void setDepth(int depth)
    {
        this.depth = depth;
    }

    public String toString()
    {
        String earthquake;

        earthquake = "Title: " + title + "\n" + "Description: "+ description + "\n" + "Latitude: "+ latitude + "\n" +"Longitude: "+ longitude;

        return earthquake;
    }
}


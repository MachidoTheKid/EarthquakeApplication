package org.me.gcu.labstuff.mappingstuff;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.util.Pair;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.maps.GoogleMap;
import com.google.android.material.datepicker.MaterialDatePicker;

import java.util.LinkedList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends AppCompatActivity {


    private GoogleMap mMap;
    RSSReader rssReader = new RSSReader();
    RSSParser rssParser = new RSSParser();
    private TextView dataDisplay;
    private ListView earthquakeDisplay;
    private String url1="";
    private String urlSource="http://quakes.bgs.ac.uk/feeds/MhSeismology.xml";
    private ArrayAdapter arrayAdapter;
    public LinkedList<Earthquake> mapList=new LinkedList<Earthquake>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Log.e("MyTag","in onCreate");
        // Set up the raw links to the graphical components
        dataDisplay = (TextView)findViewById(R.id.dataDisplay);
        earthquakeDisplay = (ListView)findViewById(R.id.earthquakeDisplay);
        Log.e("MyTag","after startButton");

        // More Code goes here

        earthquakeDisplay.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                // Get the selected name
                String selectedEarthquake = (String)parent.getItemAtPosition(position);

                // Look for Selected Earthquake, once found
                // Display the details of the Earthquake in dataDisplay
                for(int i = 0; i < rssParser.earthquakeList.size();i++)
                {
                    if(selectedEarthquake.equals(rssParser.earthquakeList.get(i).getTitle()))
                    {
                        dataDisplay.setText(rssParser.earthquakeList.get(i).toString());
                        System.out.println("EarthquakeList: "+rssParser.earthquakeList.get(i).getMagnitude());
                        mapList.clear();
                        mapList.add(rssParser.earthquakeList.get(i));
                        break;
                        // END
                    }
                }


            }
        });

        asyncPopulate(earthquakeDisplay);
        // System.out.println("THETEST: "+test);

    }



    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.main_menu, menu );
        
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){
            case R.id.item1:
                Toast.makeText(this,"Viewing Map", Toast.LENGTH_SHORT).show();
                //PASS Coordinate Data into a list, go to mapview and display that specific thing
                Intent intent = new Intent(MainActivity.this,MapsActivity.class);
                String lat= String.valueOf(mapList.get(0).getLatitude());
                String lon = String.valueOf(mapList.get(0).getLongitude());
                intent.putExtra("LATITUDE_DATA", lat);
                intent.putExtra("LONGITUDE_DATA", lon);
                startActivity(intent);
                System.out.println("Selected Quake: "+mapList.get(0).getTitle());

                return true;
            case R.id.item2:
                Toast.makeText(this,"Sort By Date", Toast.LENGTH_SHORT).show();
                MaterialDatePicker.Builder<Pair<Long, Long>> builder = MaterialDatePicker.Builder.dateRangePicker();
                builder.setTitleText("Select Dates");
                final MaterialDatePicker materialDatePicker = builder.build();
                materialDatePicker.show(getSupportFragmentManager(), "DATE_PICKER");
                return true;

            case R.id.item3:
                for(int i=0; i<mapList.size();i++){
                    String northerly = "";
                    if(mapList.get(i).getLatitude()>mapList.get(i++).getLatitude()){
                        northerly = mapList.get(i).getTitle();


                    }
                    Toast.makeText(this,"Most Northerly: "+northerly, Toast.LENGTH_LONG).show();

                }
                return true;
            case R.id.item4:
                Toast.makeText(this,"Most Northerly", Toast.LENGTH_SHORT).show();
                return true;
            case R.id.item5:
                Toast.makeText(this,"Most Southernly", Toast.LENGTH_SHORT).show();
                return true;
            case R.id.item6:
                Toast.makeText(this,"Most Westernly", Toast.LENGTH_SHORT).show();
                return true;
            case R.id.item7:
                Toast.makeText(this,"Most Easternly", Toast.LENGTH_SHORT).show();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }

    public void populate(View view){
        asyncPopulate(view);
    }

    public void storeDate(String string, MaterialDatePicker materialDatePicker){
        

    }

    public void asyncPopulate(View view){
        ExecutorService executor = Executors.newSingleThreadExecutor();
        Handler handler = new Handler(Looper.getMainLooper());

        executor.execute(new Runnable() {

            @RequiresApi(api = Build.VERSION_CODES.O)
            @Override
            public void run() {

                //Update Earthquake List
                //LinkedList<Earthquake> earthquakeList = null;
                rssReader.FetchRSS();
                rssParser.parseRSSString(rssReader.getRssString());

                for(int i = 0; i < rssParser.earthquakeList.size();i++)
                {
                    mapList.add(rssParser.earthquakeList.get(i));
                    System.out.println("MAP ITEM:"+mapList.get(i));

                }

                arrayAdapter = new ArrayAdapter(MainActivity.this, android.R.layout.simple_list_item_1, rssParser.titleList);
                //earthquakeList=rssParser.earthquakeList;
                System.out.println("IMHERE:"+rssParser.earthquakeList.get(0));



                ///////////////////////////////////////////////////////////////////////////////////
                // Clear the TextView and EditText fields
                handler.post(new Runnable() {
                    @Override
                    public void run() {
                        earthquakeDisplay.setAdapter(arrayAdapter);
                    }
                });
                ///////////////////////////////////////////////////////////////////////////////////
                handler.post(new Runnable() {
                    @Override
                    public void run() {
                        dataDisplay.setText("Select an earthquake to display data here");
                        System.out.println("Maplist test: "+mapList.get(0).getLongitude());
                        //onMapReady2(mMap, mapList,rssReader,rssParser);
                        /**/

                    }
                });
                ///////////////////////////////////////////////////////////////////////////////////

            }
        });
    }
}
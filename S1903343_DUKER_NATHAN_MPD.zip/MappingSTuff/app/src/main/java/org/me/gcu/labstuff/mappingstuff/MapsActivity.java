package org.me.gcu.labstuff.mappingstuff;

import androidx.annotation.RequiresApi;
import androidx.fragment.app.FragmentActivity;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;

import java.util.LinkedList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MapsActivity extends FragmentActivity implements OnMapReadyCallback {

    private GoogleMap mMap;
    private String url1="";
    private String urlSource="http://quakes.bgs.ac.uk/feeds/MhSeismology.xml";
    private ArrayAdapter arrayAdapter;
    public LinkedList<Earthquake> mapList=new LinkedList<Earthquake>();

    String LAT;
    String LON;

    @RequiresApi(api = Build.VERSION_CODES.O)
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maps);
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
        Intent intent=getIntent();
        LAT = intent.getStringExtra("LATITUDE_DATA");
        LON = intent.getStringExtra("LONGITUDE_DATA");

        System.out.println("ACQUIRED DATA= " +LAT+" "+LON);



        Log.e("MyTag","in onCreate");
        // Set up the raw links to the graphical components
        Log.e("MyTag","after startButton");

        // More Code goes here

       // System.out.println("THETEST: "+test);


    }


    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera. In this case,
     * we just add a marker near Sydney, Australia.
     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     */
    @RequiresApi(api = Build.VERSION_CODES.O)
    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;
        mMap.setMapType(GoogleMap.MAP_TYPE_NORMAL);
        mMap.getUiSettings().setZoomControlsEnabled(true);
        mMap.getUiSettings().setZoomGesturesEnabled(true);
        mMap.getUiSettings().setCompassEnabled(true);

        Double lat = Double.parseDouble(LAT);
        Double lon = Double.parseDouble(LON);
        LatLng location= new LatLng(lat,lon);


        LatLng quakePosition = new LatLng(lat, lon);
            // below line is use to add marker to each location of our array list.
        mMap.addMarker(new MarkerOptions().position(quakePosition).title("SELECTED LOCALE"));

            // below lin is use to zoom our camera on map.
        mMap.animateCamera(CameraUpdateFactory.zoomTo(0.02f));

            // below line is use to move our camera to the specific location.
        mMap.moveCamera(CameraUpdateFactory.newLatLng(location));

    }



}


package org.me.gcu.labstuff.mappingstuff;

import android.os.Build;

import androidx.annotation.RequiresApi;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlPullParserFactory;

import java.io.IOException;
import java.io.StringReader;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.LinkedList;
import java.util.Locale;

public class RSSParser {

    // Linked List containing top stories each with its own title, description and publication date
    LinkedList<Earthquake> earthquakeList = null;

    // A LINKED LIST FOR HOLDING THE TITLES OF TOP STORIES
    // TO BE USED IN LISTVIEW
    LinkedList <String>  titleList = null;


    @RequiresApi(api = Build.VERSION_CODES.O)
    public LinkedList<Earthquake> parseRSSString(String rssString)
    {
        Earthquake earthquake = new Earthquake();

        try
        {
            XmlPullParserFactory factory = XmlPullParserFactory.newInstance();
            factory.setNamespaceAware(true);
            XmlPullParser xpp = factory.newPullParser();
            xpp.setInput( new StringReader( rssString ) );
            int eventType = xpp.getEventType();


            while (eventType != XmlPullParser.END_DOCUMENT)
            {

                // Found a start tag
                if(eventType == XmlPullParser.START_TAG)
                {
                    // Check which Tag we have
                    if (xpp.getName().equalsIgnoreCase("channel"))
                    {
                        earthquakeList  = new LinkedList<Earthquake>();
                        titleList     = new LinkedList<String>();

                        /*xpp.next();
                        while (xpp.getName()!=null && (!xpp.getName().equalsIgnoreCase("item"))){
                            eventType=xpp.next();
                        }*/
                        for(int i=0; i<11;i++){
                            eventType=xpp.next();
                        }
                    }
                    else
                    if (xpp.getName().equalsIgnoreCase("item"))
                    {
                        earthquake = new Earthquake();
                    }
                    else
                    if (xpp.getName().equalsIgnoreCase("title"))
                    {
                        // Now just get the associated text
                        String temp = xpp.nextText();
                        earthquake.setTitle(temp);
                        System.out.println("THE TITLE IS: "+earthquake.getTitle());

                    }
                    else
                        // Check which Tag we have
                        if (xpp.getName().equalsIgnoreCase("description"))
                        {
                            // Now just get the associated text
                            String temp = xpp.nextText();
                            earthquake.setDescription(temp);
                            String[] consolidatedInfo = temp.split(";");


                            ////Magnitude
                            String magInfo = consolidatedInfo[4];
                            String[] magnitudeString = magInfo.split(":");
                            Double magnitude = Double.parseDouble(magnitudeString[1]);
                            earthquake.setMagnitude(magnitude);
                            System.out.println("THE MAG IS: "+magnitude);

                            ///Depth
                            String depthInfo = consolidatedInfo[3];
                            String[] depthString = depthInfo.split(":");
                            String[] depthStringTwo = depthString[1].split("km");
                            String[] depthSplit = depthStringTwo[0].split(" ");
                            //earthquake.setDepth(depth);
                            int depth = Integer.parseInt(depthSplit[1]);
                            earthquake.setDepth(depth);
                            System.out.println("THE DEPTH IS: "+earthquake.getDepth());

                            //Date: Split Description Data. Use 2021 to split away from the time.

                            String dateInfo = "Mon, 05 May 1980";
                            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("EEE, d MMM yyyy", Locale.ENGLISH);
                            LocalDate dateTime = LocalDate.parse(dateInfo, formatter);
                            System.out.println("DATE TEST: "+dateTime);


                            ///Description
                            System.out.println("THE DESC IS: "+earthquake.getDescription());
                        }
                        else
                            // Check which Tag we have
                            if ((xpp.getName()!=null) && (xpp.getName().equalsIgnoreCase("link")))
                            {
                                // Now just get the associated text
                                String temp = xpp.nextText();
                                earthquake.setLink(temp);
                                System.out.println("THE LINK IS: "+earthquake.getLink());
                            }
                            else
                                if(xpp.getName().equalsIgnoreCase("pubdate"))
                                {

                                    String temp = xpp.nextText();
                                    earthquake.setPubDate(temp);
                                    System.out.println("THE PUBDATE IS: "+earthquake.getPubDate());
                                }
                            else
                                if(xpp.getName().equalsIgnoreCase("category"))
                                {
                                    String temp = xpp.nextText();
                                    earthquake.setCategory(temp);
                                    System.out.println("THE CAT IS: "+earthquake.getCategory());

                                }
                                else
                                    if (xpp.getName().equalsIgnoreCase("lat")) {

                                        String temp = xpp.nextText();
                                        ///double val = Double.parseDouble(temp);
                                        //System.out.println(val);
                                        earthquake.setLatitude(Double.parseDouble(temp));
                                        System.out.println("THE LAT IS:" + earthquake.getLatitude());

                                    }else
                                        if (xpp.getName().equalsIgnoreCase("long")){
                                            String temp = xpp.nextText();
                                            earthquake.setLongitude(Double.parseDouble(temp));
                                            System.out.println("THE LON IS: "+earthquake.getLongitude());

                                        }
                }
                else
                if(eventType == XmlPullParser.END_TAG)
                {
                    if (xpp.getName().equalsIgnoreCase("item"))
                    {
                        earthquakeList.add(earthquake);
                        titleList.add(earthquake.getTitle());
                    }
                    else
                    if (xpp.getName().equalsIgnoreCase("channel"))
                    {
                        int size;
                        size = earthquakeList.size();
                    }
                }

                // Get the next event
                eventType = xpp.next();
            }

        }

        catch (XmlPullParserException e)
        {
            System.out.println("Parsing Error "+e.toString());
        }

        catch (IOException e)
        {
            System.out.println("Parsing Error "+e.toString());
        }
        return earthquakeList;
    }
}
